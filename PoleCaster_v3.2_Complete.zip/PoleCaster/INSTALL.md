# 🎙️ PoleCaster — Guía de Instalación y Compilación
## Cómo construir el Setup.exe para Windows

---

## 📋 Requisitos previos (instalar una sola vez)

### 1. Python 3.10 o superior
- Descargar desde: https://www.python.org/downloads/
- ✅ Marcar "Add Python to PATH" durante la instalación

### 2. VLC Media Player (64-bit)
- Descargar desde: https://www.videolan.org/vlc/
- Necesario para la reproducción de audio

### 3. FFmpeg
- Descargar desde: https://ffmpeg.org/download.html
- Extraer y agregar la carpeta `bin` al PATH de Windows

### 4. Inno Setup 6 (para crear el instalador)
- Descargar desde: https://jrsoftware.org/isinfo.php

---

## 🚀 Paso 1: Instalar dependencias Python

Abrir CMD o PowerShell en la carpeta del proyecto y ejecutar:

```cmd
pip install PyQt6 python-vlc requests pyinstaller
```

---

## 🔨 Paso 2: Compilar el .exe con PyInstaller

```cmd
pyinstaller PoleCaster.spec
```

Esto genera la carpeta `dist\PoleCaster\` con todos los archivos del programa.

**Alternativa simple (sin .spec):**
```cmd
pyinstaller --noconsole --onedir --name=PoleCaster polecaster.py
```

---

## 📦 Paso 3: Crear el Setup.exe con Inno Setup

1. Abrir **Inno Setup Compiler**
2. Abrir el archivo `setup_installer.iss`
3. Clic en **Build → Compile** (o Ctrl+F9)
4. El instalador se genera en `dist_installer\PoleCaster_Setup_v1.0.exe`

---

## ✅ Resultado final

```
dist_installer\
└── PoleCaster_Setup_v1.0.exe   ← ¡Este es tu instalador!
```

El usuario solo necesita hacer doble clic en ese archivo y seguir el asistente de instalación, igual que cualquier software de Windows.

---

## 🗂️ Estructura del proyecto

```
PoleCaster\
├── polecaster.py          ← Código principal
├── requirements.txt       ← Dependencias Python
├── PoleCaster.spec        ← Config de PyInstaller
├── setup_installer.iss    ← Script de Inno Setup
├── assets\                ← Íconos e imágenes
├── jingles\               ← Carpeta de jingles por defecto
├── music\                 ← Carpeta de música por defecto
└── logs\                  ← Registros del programa
```

---

## 🎯 Funciones incluidas en v1.0

### Automatizador (como ZaraRadio)
- ✅ Playlist con soporte MP3, WAV, OGG, FLAC, AAC, WMA
- ✅ Tipos de pista: Música, Jingle, Spot publicitario
- ✅ Jingles rápidos F1–F9
- ✅ Scheduler de eventos por hora
- ✅ Controles Play/Pause/Stop/Siguiente/Anterior
- ✅ Barra de progreso en tiempo real
- ✅ VU meter animado
- ✅ Crossfade configurable entre canciones
- ✅ Modo 24/7 (auto-avance de canciones)
- ✅ Guardar/cargar playlists (.pcp)
- ✅ Reloj en tiempo real

### Streaming (como RadioBOSS)
- ✅ Conexión a Icecast2 / Shoutcast
- ✅ Bitrate: 64k / 128k / 192k / 320k
- ✅ Formatos: MP3, AAC, OGG
- ✅ Metadata automática (artista/título al servidor)
- ✅ Monitor de oyentes en vivo
- ✅ Reconexión automática
- ✅ Configuración de estación (nombre, género, URL)

---

## 📞 Soporte

Si tienes problemas con la instalación, consulta la documentación de:
- PyQt6: https://doc.qt.io/qtforpython/
- python-vlc: https://python-vlc.readthedocs.io/
- AzuraCast (servidor): https://azuracast.com/docs/
