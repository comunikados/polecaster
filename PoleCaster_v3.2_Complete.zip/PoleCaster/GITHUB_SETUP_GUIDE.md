# 🚀 Guía: Obtener el Setup.exe de PoleCaster desde GitHub

## Lo que va a pasar:
Subes el código a GitHub → GitHub compila en Windows → Descargas el Setup.exe ✅

---

## PASO 1 — Crear cuenta en GitHub (si no tienes)
👉 https://github.com/signup
- Es gratis, solo necesitas email

---

## PASO 2 — Crear repositorio nuevo
1. Entra a https://github.com/new
2. Nombre del repositorio: `polecaster`
3. Selecciona **Private** (para que sea tuyo)
4. Clic en **Create repository**

---

## PASO 3 — Subir los archivos
En la página del repositorio vacío:
1. Clic en **"uploading an existing file"**
2. Arrastra TODOS los archivos del ZIP que descargaste:
   - `polecaster.py`
   - `requirements.txt`
   - `setup_installer.iss`
   - `PoleCaster.spec`
   - La carpeta `.github/workflows/build_windows.yml`
3. Clic en **"Commit changes"**

> ⚠️ La carpeta `.github` es oculta en Windows.
> Para verla: Explorador → Ver → Mostrar elementos ocultos

---

## PASO 4 — Ver cómo compila automáticamente
1. En tu repositorio, clic en la pestaña **"Actions"**
2. Verás el workflow **"Build PoleCaster Windows Installer"** ejecutándose
3. Espera ~5-8 minutos (los servidores de GitHub instalan todo)
4. Cuando aparezca ✅ verde = ¡listo!

---

## PASO 5 — Descargar el Setup.exe
1. Clic en el workflow que terminó con ✅
2. Baja hasta la sección **"Artifacts"**
3. Clic en **"PoleCaster_Setup_Windows"**
4. Se descarga un ZIP con el **PoleCaster_Setup_v2.0.exe** dentro
5. Doble clic en el Setup → instalar → ¡a transmitir! 🎙️

---

## ¿Dónde queda instalado?
```
C:\Program Files\PoleCaster\
└── PoleCaster.exe   ← acceso directo en escritorio también
```

---

## Ejecutar manualmente (si quieres volver a compilar)
1. Pestaña Actions → "Build PoleCaster Windows Installer"
2. Clic en **"Run workflow"** → **"Run workflow"**
3. Espera y descarga

---

## ¿Problemas?
- Si el workflow falla, mándame el error en rojo y lo resuelvo
- El Setup.exe queda guardado 30 días en GitHub
